//My name is Daniel Kelley and this is part of my final project for CS110. This contains the data for a BattleShip object, which is a Ship.
public class Battleship extends Ship
{
   /*This is the BattleShip constructor.
      It takes in no arguments, and just calls the super constructor with a size of 4.
   */
   public Battleship()
   {
      super(4);
   }
   
}