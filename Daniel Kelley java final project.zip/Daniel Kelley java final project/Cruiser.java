//My name is Daniel Kelley and this is part of my CS110 final project. This class has the data for a Cruiser object, which is a ship.
public class Cruiser extends Ship
{
   /*This is the Cruiser constructor
      It takes in no arguments, and just calls the super constructor with an argument of 3.
   */
   public Cruiser()
   {
      super(3);
   }
}