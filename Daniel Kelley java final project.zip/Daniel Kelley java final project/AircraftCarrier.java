//My name is Daniel Kelley and this is part of my final project for CS110. This contains the data for an Aircraft Carrier object, which is a Ship.
public class AircraftCarrier extends Ship
{
   /*This is the AircraftCarrier constructor.
      It takes in no arguments, and just calls the super constructor with a size of 5.
   */
   public AircraftCarrier()
   {
      super(5);
   }
}