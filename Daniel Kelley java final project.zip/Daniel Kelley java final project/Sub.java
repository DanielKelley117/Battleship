//My name is Daniel Kelley and this is part of my CS110 final project. This class contains the data for a Sub object, which is a ship.
public class Sub extends Ship
{
   /*This is the Sub constructor. 
      This constructor takes in no arguments, and just calls the superconstructor with an argument of 3.
   */
   public Sub()
   {
      super(3);
   }
}